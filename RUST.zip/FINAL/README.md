# drone2human — Rust Implementation

This project implements the authentication phase between the drone and the receiver.  
The Provider is assumed to be *trusted* and supplies each party with:

- RSA key pairs
- Signed capability tokens (`tokenR.json`, `tokenD.json`)

The communication is implemented in **Rust**, uses **OpenSSL** for RSA and SHA-256. This guide is intended for these OS's:

- macOS (Apple Silicon)
- Linux x86_64
- Linux ARM (Raspberry Pi)

---

# Protocol Overview (Drone ↔ Receiver)

The protocol runs over a TCP connection on port **8080**.

Both peers load:

- their own private key  
- the other peer's public key  
- the Provider's public key  
- their own signed token  

The protocol consists of the following steps:

---

## 1. INIT_AUTH (Receiver → Drone)

Receiver generates a random challenge (`challengeR`) and sends:

```json
{
  "type": "INIT_AUTH",
  "challengeR": "<hex_random_16B>",
  "capabilityR": {
      "token": tokenR,
      "sig": "<signature(tokenR)>"
  }
}
```
---
Drone verifies:
- `tokenR` signature using Provider's public key
- `owner_mark(R)` = HEX(SHA256(receiver_pub_key_pem))
- Extracts `order_id` and `nonce_session` from `tokenR`
- Stores Receiver’s challenge (`challengeR`)
---
## 2. DRONE_RESPONSE (Drone → Receiver)

Drone generates:
- `challengeD` = random_hex(16 bytes)
- `auth_string_D` = `challengeR` | `nonce_session` | `order_id`
- `responseD` = SIGN(drone_private_key, auth_string_D)
    > **IMPORTANT**: *rsa_sign* function comprehends the HASH of the data before the encryption. Hence, even the RSA verify, initially decrypts the input and then it compares it with the HASH of the initial data. (check *crypto_utils.rs*)
---
Drone sends:
```json
{
  "type": "DRONE_RESPONSE",
  "capabilityD": {
      "token": tokenD,
      "sig": "<signature(tokenD)>"
  },
  "challengeD": "<hex>",
  "responseD": "<hex(signature)>"
}
```
---
Receiver verifies:
- `tokenD` signature
- `owner_mark(D)` = hex(sha256(`drone_pub_key_pem`))
- Drone's signature over `auth_string_D` hashed
---
## 3. RECEIVER_FINAL (Receiver → Drone)
Receiver computes:
- `auth_string_R` = `challengeD` | `nonce_session` | `order_id`
- `responseR` = SIGN(`receiver_private_key`, `auth_string_R`)
---
Receiver sends:
```json
{
  "type": "RECEIVER_FINAL",
  "responseR": "<hex(signature)>"
}
```
---
Drone verifies:
- Receiver's RSA signature on `auth_string_R` hashed
---
If valid:
> **Mutual Authentication Completed**

## 4. Receiver and Drone Store Evidence
At the end of the authentication protocol, both the Receiver and the Drone generate and locally store cryptographic evidence of the delivery event (saved in the folder "/logs/"). Such evidence attests that the mutual authentication was successfully completed and that the delivery took place within the correct context.

The stored evidence can be used for a posteriori verification, auditing purposes, or dispute resolution, ensuring accountability of the invol


## TLS Encryption
The protocol requires a secure communication channel for the exchange of messages. For this reason, all interactions between the involved entities are performed over a TLS layer, which guarantees confidentiality, integrity, and endpoint authentication.


# Rust Libraries Used

| Crate | Purpose |
|-------|---------|
| **openssl** | RSA signing & verification, SHA256 hashing, random bytes generation |
| **hex** | Binary ↔ Hex encoding and decoding |
| **serde_json** | Serialization and deserialization of JSON capability tokens

> These crates together provide fully secure cryptographic operations (openssl) and safe serialization (hex, serde_json).

---

# Requirements

## 1. Install Rust
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```
> Follow standard instructions (usually press option **1**)
---
## 2. Export PATHs
### Linux
```bash
export PATH="$HOME/.cargo/bin:$PATH"
source ~/.bashrc
```
---
### macOS
```bash
export PATH="$HOME/.cargo/bin:$PATH"
source ~/.zshrc
```
---
## 3. Install OpenSSL

### macOS (Apple Silicon)
```bash
brew install openssl@3
export LDFLAGS="-L/opt/homebrew/opt/openssl@3/lib"
export CPPFLAGS="-I/opt/homebrew/opt/openssl@3/include"
export PKG_CONFIG_PATH="/opt/homebrew/opt/openssl@3/lib/pkgconfig"
```
---
### Linux
```bash
sudo apt update
sudo apt install -y libssl-dev pkg-config build-essential
```
---
# Build Instructions
To compile the project (from root):
```bash
cargo build
```
---
If it does not build because of an old cargo version:
```bash
rustup update
```
---

# Running the Protocol LOCALLY
Open two separate terminals on root directory

## Terminal 1
```bash
cargo run --bin drone_server
```
---
Expected output:
```bash
[DRONE] Listening on port 8080...
```
---

## Terminal 2
```bash
cargo run --bin receiver_client
```
---
Expected output:
```bash
[RECEIVER] Connected to drone.
(...)
```
---

# Running the Protocol on RPi and Android (RPi and Android)

## RPi Terminal
```bash
cargo run --bin drone_demo
```
---
The script setups the Wi-Fi Direct on the RPi, which outputs the Wi-Fi password and then starts the protocol (and waits until the receiver connects).

## AndroidStudio application

run the application from AndroidStudio (by connecting an Android smartphone through cable to the pc). Download the application start it.

Press the CONNECT button, connect to the Wi-Fi if not connected. Accept then the request "connect without Internet".

Once connected, the CONNECT button starts automatically the protocol

---




