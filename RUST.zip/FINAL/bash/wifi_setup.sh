#!/bin/bash

echo "--- 1. Data Setup (RPi def date is set on 2020)  ---"
sudo date -s "2026-02-14 12:00:00"

sleep 3 # Aumentato per stabili
echo "--- 2. Cleanup ---"
sudo killall wpa_supplicant dnsmasq 2>/dev/null
sudo systemctl stop systemd-resolved
sudo ip link set wlan0 up
sleep 1

echo "--- 3. Starting wpa_supplicant ---"
sudo wpa_supplicant -B -i wlan0 -c /etc/wpa_supplicant/p2p.conf 2>/dev/null
sudo wpa_cli -i wlan0 p2p_group_add 2>/dev/null

IFACE=$(ip addr | grep -oE "p2p-wlan0-[0-9]+" | head -n 1)
if [ -z "$IFACE" ]; then IFACE="p2p-wlan0-0"; fi # Fallback

sudo ip addr flush dev $IFACE
sudo ip addr add 192.168.4.1/24 dev $IFACE
sudo ip link set $IFACE up

sudo dnsmasq -C /dev/null -i $IFACE --port=0 --dhcp-range=192.168.4.10,192.168.4.50,12h

echo "--------------------------------------"
echo " ** NETWORK READY **"
PASS=$(sudo wpa_cli -i $IFACE p2p_get_passphrase)
SSID=$(sudo wpa_cli -i $IFACE status | grep ^ssid= | cut -d= -f2)
echo "SSID: $SSID"
echo "PASSWORD: $PASS"
echo "--------------------------------------"