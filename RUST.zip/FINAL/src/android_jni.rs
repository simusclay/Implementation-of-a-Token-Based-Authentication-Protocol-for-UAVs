use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;

use android_logger::Config;
use log::LevelFilter;
use std::sync::Once;

static LOGGER: Once = Once::new();

use crate::auth_config::{AuthConfig};
use crate::receiver_logic::receiver_run;

#[no_mangle]
pub extern "C" fn Java_com_example_dtlsapp_MainActivity_runClient(
    mut env: JNIEnv,
    _class: JClass,
    server_addr: JString,
    sni: JString,

    receiver_cert: JString,
    receiver_key: JString,
    ca_cert: JString,

    receiver_privkey_pem: JString,
    drone_pubkey_pem: JString,
    provider_pubkey_pem: JString,

    token_r_json: JString,
    sig_token_r_hex: JString,

    evidence_path: JString,
) -> jstring {
    let mut to_string = |x: JString| -> String { 
        env.get_string(&x).map(|s| s.into()).unwrap_or_default() 
    };
    LOGGER.call_once(|| {
        android_logger::init_once(
            Config::default()
                .with_tag("DRONE_AUTH")
                .with_max_level(LevelFilter::Debug),
        );
    });

    log::error!("JNI entered: runClient()");

    let cfg = AuthConfig {
        listen_addr: None,
        server_addr: Some(to_string(server_addr)),
        sni: Some(to_string(sni)),

        self_cert: to_string(receiver_cert),
        self_pubkey: to_string(receiver_key),
        ca_cert: to_string(ca_cert),

        self_privkey: to_string(receiver_privkey_pem),
        peer_pubkey: to_string(drone_pubkey_pem),
        provider_pubkey: to_string(provider_pubkey_pem),

        token: to_string(token_r_json),
        sig_token: to_string(sig_token_r_hex),

        evidence_path: to_string(evidence_path),
    };

    match receiver_run(cfg) {
    Ok(_) => {
        let output = env.new_string("OK").expect("Failed to create JString");
        output.into_raw()
    }
    Err(e) => {
            let err_msg = format!("{:?}", e);
            log::error!("[JNI] DTLSAPP error: {}", err_msg);
            
            let output = env.new_string(err_msg).expect("Failed to create JString");
            output.into_raw()
        }
}

}
