/* Concatenates the authentication string as follows:
 *     challenge | nonce_session | order_id 
 */
pub fn make_auth_string(challenge: &str, nonce_session: &str, order_id: &str) -> String {
    format!("{challenge}|{nonce_session}|{order_id}")
}