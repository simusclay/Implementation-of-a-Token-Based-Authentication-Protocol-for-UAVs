use std::error::Error;
use std::fs;
use std::io::{Read, Write};
use std::net::UdpSocket;
use std::time::Instant;

use openssl::sha::sha256;
use serde_json::Value as Json;

use crate::crypto_utils::*;
use crate::protocol_utils::*;
use crate::evidence_utils::*;
use crate::tls_utils::{build_dtls_connector, ConnectedUdpStream};
use crate::auth_config::AuthConfig;

const USE_LOG: bool = false; /* 
                             * true = out (android use case),
                             * false = println! (local test cases)
                             */

fn out(msg: &str) {
    if USE_LOG {
        log::error!("{}", msg);
    } else {
        println!("{}", msg);
    }
}

pub fn receiver_run(cfg: AuthConfig) -> Result<(), Box<dyn Error>> {

    /* key loading */
    let receiver_private_key = load_private_key(&cfg.self_privkey)?;
    let drone_public_key = load_public_key(&cfg.peer_pubkey)?;
    let provider_public_key = load_public_key(&cfg.provider_pubkey)?;

    /* tokenR & sig_tokenR loading (provided by P) */
    let receiver_token: Json =
        serde_json::from_slice(&fs::read(&cfg.token)?)?;
    let receiver_token_signature_hex =
        String::from_utf8(fs::read(&cfg.sig_token)?)?;

    /* create expected receiver owner_mark (HASH(PU_D)) for later use */
    let drone_public_key_hash_hex =
        hex::encode(sha256(&fs::read(&cfg.peer_pubkey)?));

    /*---------------------------------------------------------------------------*/
    /*                      DTLS (UDP) SOCKET INITIALIZATION                     */
    /*---------------------------------------------------------------------------*/
    let connector = build_dtls_connector(
        &cfg.self_cert,
        &cfg.self_privkey,
        &cfg.ca_cert
    )?;

    let socket = UdpSocket::bind("0.0.0.0:0")?;

    /* Start timer for runtime */    
    let start = Instant::now();

    let addr = cfg.server_addr.as_ref().ok_or("Drone address is set to None (must be set)")?;
    socket.connect(addr)?;
    out("[RECEIVER] Connected to drone UDP on {addr}. Starting DTLS handshake...");


    let sni = cfg.sni.as_ref().ok_or("Drone SNI is set to None (must be set)")?;


    let udp_stream = ConnectedUdpStream::new_connected(socket);

    let mut stream = connector.connect(sni, udp_stream)?;

    out("[RECEIVER] DTLS handshake OK.\n");



    /*---------------------------------------------------------------------------*/
    /*    Step 1: RECEIVER INITIATES AUTHENTICATION (capabilityR + challengeR)   */
    /*---------------------------------------------------------------------------*/
    let receiver_challenge = random_hex_string(16)?;
    out(&format!("[RECEIVER] Generated challengeR: {receiver_challenge}"));

    /* create capabilityR = (tokenR, sig_tokenR) */
    let receiver_capability = serde_json::json!({
        "token": receiver_token,
        "sig": receiver_token_signature_hex.trim(),
    });
    /* create INIT_AUTH msg = (capabilityR, challengeR) */
    let init_auth_message = serde_json::json!({
        "type": "INIT_AUTH",
        "challengeR": receiver_challenge,
        "capabilityR": receiver_capability,
    });
    /* send INIT_AUTH msg */
    let init_auth_json = init_auth_message.to_string();
    stream.write_all(init_auth_json.as_bytes())?;
    out(&format!("[RECEIVER] Sent INIT_AUTH (capabilityR, challengeR) ({} bytes).\n",
        init_auth_json.len()));

    /*---------------------------------------------------------------------------*/
    /*             Step 4: DRONE VERIFICATION (tokenD + owner_mark)              */
    /*---------------------------------------------------------------------------*/
    /* reading DRONE_RESPONSE msg D → R: (capabilityD, challengeD, responseD) */
    let mut recv_buffer = [0u8; 4096];
    let bytes_read = stream.read(&mut recv_buffer)?;
    if bytes_read == 0 {
        return Err("[RECEIVER] read() failed on DRONE_RESPONSE (0 bytes)".into());
    }

    let drone_response_raw =
        String::from_utf8_lossy(&recv_buffer[..bytes_read]).to_string();
    out(
        &format!("[RECEIVER] Reading DRONE_RESPONSE ({bytes_read} bytes).")
    );

    let drone_response_message: Json = serde_json::from_str(&drone_response_raw)?;
    if drone_response_message["type"] != "DRONE_RESPONSE" {
        return Err("[RECEIVER] Unexpected message type (expected DRONE_RESPONSE)".into());
    }



    let drone_capability = &drone_response_message["capabilityD"];
    let drone_token = &drone_capability["token"];

    let drone_token_signature = hex::decode(
        drone_capability["sig"]
            .as_str()
            .ok_or("[RECEIVER] Missing sig in capabilityD")?,
    )?;

    let drone_challenge = drone_response_message["challengeD"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    let drone_response_signature = hex::decode(
        drone_response_message["responseD"]
            .as_str()
            .unwrap_or_default(),
    )?;

    out(&format!("[RECEIVER] challengeD: {drone_challenge}"));

    /* tokenD verify */
    let drone_token_bytes = serde_json::to_vec(drone_token)?;
    if !rsa_verify(
        &provider_public_key,
        &drone_token_bytes,
        &drone_token_signature,
    )? {
        return Err("[RECEIVER] drone_token signature INVALID (Provider).".into());
    }
    out("[RECEIVER] drone_token signature OK.");

    /* owner_mark verify */
    let drone_owner_mark = drone_token["owner_mark"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    if drone_owner_mark != drone_public_key_hash_hex {
        out("[RECEIVER] drone_token owner_mark mismatch!");
    } else {
        out("[RECEIVER] drone_token owner_mark matches drone_pub.");
    }

    let order_id = drone_token["order_id"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    let nonce_session = drone_token["nonce_session"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    out(
        &format!("[RECEIVER] order_id={order_id} nonce_session={nonce_session}")
    );

    /* 1. create: (challengeR || nonce_session || order_id) */
    let drone_auth_string = make_auth_string(&receiver_challenge, &nonce_session, &order_id);
    /* 2. responseD (Sign(PR_D, HASH(challengeR || nonce_session || order_id))) verify 
     * IMPORTANT:
     *     the HASH(), more precisely SHA256(), happens inside rsa_verify()
     */
    if !rsa_verify(
        &drone_public_key,
        &drone_auth_string.as_bytes(),
        &drone_response_signature,
    )? {
        return Err("[RECEIVER] ERROR: Drone SIGNATURE INVALID!".into());
    }
    out("[RECEIVER] Drone SIGNATURE VALID.\n");

    /*---------------------------------------------------------------------------*/
    /*                   Step 5: RECEIVER RESPONSE (responseR)                   */
    /*---------------------------------------------------------------------------*/
    /* 1. create: (challengeD || nonce_session || order_id) */
    let receiver_auth_string = make_auth_string(&drone_challenge, &nonce_session, &order_id);
    /* 2. create responseR = Sign(PR_R, HASH(challengeD || nonce_session || order_id)) */
    let receiver_response_signature_hex =
        hex::encode(rsa_sign(&receiver_private_key, &receiver_auth_string.as_bytes())?);
    
    /* 3. send responseR */
    let receiver_final_message = serde_json::json!({
        "type": "RECEIVER_FINAL",
        "responseR": receiver_response_signature_hex,
    });

    let receiver_final_json = receiver_final_message.to_string();
    stream.write_all(receiver_final_json.as_bytes())?;
    out(&format!( "[RECEIVER] Sent RECEIVER_FINAL (responseR) ({} bytes).\n",
        receiver_final_json.len()));

    /*---------------------------------------------------------------------------*/
    /*       Step 7: RECEIVE AUTH_RESULT (Drone ACK) and store evidence          */
    /*---------------------------------------------------------------------------*/
    let mut recv_buffer = [0u8; 4096];
    let bytes_read = stream.read(&mut recv_buffer)?;
    out(&format!("[RECEIVER] Reading AUTH_RESULT ({bytes_read} bytes)."));

    if bytes_read == 0 {
        return Err("[RECEIVER] read() failed on AUTH_RESULT (0 bytes)".into());
    }

    let auth_result_raw = String::from_utf8_lossy(&recv_buffer[..bytes_read]).to_string();
    let auth_result_msg: Json = serde_json::from_str(&auth_result_raw)?;
    if auth_result_msg["type"] != "AUTH_RESULT" {
        return Err("[RECEIVER] Unexpected message type (expected AUTH_RESULT)".into());
    }


    let status = auth_result_msg["status"].as_str().unwrap_or("FAIL");
    let ts = auth_result_msg["ts"].as_u64().unwrap_or(0);
    let sig_hex = auth_result_msg["sig"].as_str().unwrap_or("");
    let sig = hex::decode(sig_hex)?;

    let ack_payload = format!("AUTH_RESULT|{}|{}|{}|{}", status, order_id, nonce_session, ts);

    /* Check if the ack is actually from the Drone by rsa_verify */
    let ack_ok = rsa_verify(&drone_public_key, ack_payload.as_bytes(), &sig)?;
    if !ack_ok || status != "OK" {
        return Err("[RECEIVER] AUTH_RESULT signature invalid".into());
    }
    else {
        out("[RECEIVER] drone AUTH_RESULT VALID.");

        out("[RECEIVER] Mutual auth completed!");
        store_auth_evidence(
            "AUTH_OK",
            "RECEIVER",
            &cfg.evidence_path,
            &order_id,
            &nonce_session,
            &receiver_private_key,
            ts
        )?;
        out("[RECEIVER] Evidence successfully written.");
    }

    /* Stop timer for runtime */
    let duration = start.elapsed();
    out(&format!("\nRun time: {:?}", duration));

    Ok(())
}
