use serde::{Deserialize, Serialize};
use std::error::Error;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::Path;

use crate::crypto_utils::{rsa_sign, PrivateKey};

#[derive(Debug, Serialize, Deserialize)]
pub struct AuthEvidence {
    pub role: String,
    pub status: String,          // "AUTH_OK" | "AUTH_FAIL"
    pub order_id: String,
    pub nonce_session: String,
    pub timestamp_unix: u64,
    pub payload: String,         
    pub signature_hex: String,   

}

fn build_payload(status: &str, order_id: &str, nonce_session: &str, ts: u64) -> String {
    format!("{status}|{order_id}|{nonce_session}|{ts}")
}

fn append_jsonl<P: AsRef<Path>>(path: P, line: &str) -> Result<(), Box<dyn Error>> {
    if let Some(parent) = path.as_ref().parent() {
        fs::create_dir_all(parent)?;
    }
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    writeln!(f, "{}", line)?;
    Ok(())
}

pub fn store_auth_evidence<P: AsRef<Path>>(
    status: &str,
    role: &str,
    out_path: P,
    order_id: &str,
    nonce_session: &str,
    signer_sk: &PrivateKey,
    ts: u64,
) -> Result<(), Box<dyn Error>> {
    let payload = build_payload(status, order_id, nonce_session, ts);
    let sig = rsa_sign(signer_sk, payload.as_bytes())?;
    let sig_hex = hex::encode(sig);

    let evidence = AuthEvidence {
        status: status.to_string(),
        role: role.to_string(),
        order_id: order_id.to_string(),
        nonce_session: nonce_session.to_string(),
        timestamp_unix: ts,
        payload,
        signature_hex: sig_hex,
    };

    let json_line = serde_json::to_string(&evidence)?;
    append_jsonl(out_path, &json_line)?;
    Ok(())
}
