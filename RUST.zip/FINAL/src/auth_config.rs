pub struct AuthConfig {
    pub listen_addr: Option<String>,
    pub server_addr: Option<String>,
    pub sni: Option<String>,

    pub self_cert: String,
    pub self_pubkey: String,
    pub ca_cert: String,

    pub self_privkey: String,
    pub peer_pubkey: String,
    pub provider_pubkey: String,

    pub token: String,
    pub sig_token: String,

    pub evidence_path: String,
}