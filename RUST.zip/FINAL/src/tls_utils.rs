use openssl::ssl::{SslAcceptor, SslConnector, SslFiletype, SslMethod, SslVerifyMode};
use std::error::Error;
use std::io::{Read, Write};
use std::net::UdpSocket;

#[derive(Debug)]
pub struct ConnectedUdpStream {
    socket: UdpSocket,
    first_datagram: Option<Vec<u8>>,
}

impl ConnectedUdpStream {
    pub fn new_connected(socket: UdpSocket) -> Self {
        Self {
            socket,
            first_datagram: None,
        }
    }

    pub fn new_connected_with_first_datagram(socket: UdpSocket, datagram: Vec<u8>) -> Self {
        Self {
            socket,
            first_datagram: Some(datagram),
        }
    }
}

impl Read for ConnectedUdpStream {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        /* If first_datagram is not None, then it saves the entry in dg and sets first_datagram to None,
         *     otherwise it skips to the recv()
         */
        if let Some(dg) = self.first_datagram.take() {
            if dg.len() > buf.len() {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::InvalidData,
                    "Buffered UDP datagram larger than read buffer",
                ));
            }
            buf[..dg.len()].copy_from_slice(&dg);
            return Ok(dg.len());
        }

        self.socket.recv(buf)
    }
}

impl Write for ConnectedUdpStream {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.socket.send(buf)
    }

    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

pub fn build_dtls_acceptor(
    server_cert: &str,
    server_key: &str,
    ca_cert: &str,
) -> Result<SslAcceptor, Box<dyn Error>> {
    let mut builder = SslAcceptor::mozilla_intermediate(SslMethod::dtls())?;
    builder.set_certificate_chain_file(server_cert)?;
    builder.set_private_key_file(server_key, SslFiletype::PEM)?;
    builder.check_private_key()?;
    builder.set_ca_file(ca_cert)?;
    builder.set_verify(SslVerifyMode::PEER | SslVerifyMode::FAIL_IF_NO_PEER_CERT);
    Ok(builder.build())
}

pub fn build_dtls_connector(
    client_cert: &str,
    client_key: &str,
    ca_cert: &str,
) -> Result<SslConnector, Box<dyn Error>> {
    let mut builder = SslConnector::builder(SslMethod::dtls())?;
    /* 
     * openssl functions used in "build_dtls_acceptor" function 
     * do not work properly with Android, therefore openssl functions
     * that use the path of certificates were switched with the ones that use directly the 
     * certificates. 
     */

    /* load path into memory */
    let cert_bytes = std::fs::read(client_cert)?;
    let key_bytes = std::fs::read(client_key)?;
    let ca_bytes = std::fs::read(ca_cert)?;

    let cert = openssl::x509::X509::from_pem(&cert_bytes)?;
    let key = openssl::pkey::PKey::private_key_from_pem(&key_bytes)?;
    
    builder.set_certificate(&cert)?;
    builder.set_private_key(&key)?;

    let ca = openssl::x509::X509::from_pem(&ca_bytes)?;
    builder.cert_store_mut().add_cert(ca)?;

    builder.check_private_key()?;
    builder.set_verify(SslVerifyMode::PEER);

    Ok(builder.build())
}

// pub fn build_dtls_connector(
//     client_cert: &str,
//     client_privkey: &str,
//     ca_cert: &str,
// ) -> Result<SslConnector, Box<dyn Error>> {
//     let mut builder = SslConnector::builder(SslMethod::dtls())?;

//     builder.set_ca_file(ca_cert)?;

//     builder.set_certificate_file(client_cert, SslFiletype::PEM)?;
//     builder.set_private_key_file(client_privkey, SslFiletype::PEM)?;
//     builder.check_private_key()?;

//     builder.set_verify(SslVerifyMode::PEER);

//     Ok(builder.build())
// }

