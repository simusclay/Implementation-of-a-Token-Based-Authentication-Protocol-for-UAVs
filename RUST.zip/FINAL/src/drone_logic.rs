use std::error::Error;
use std::fs;
use std::io::{Read, Write};
use std::net::UdpSocket;
use std::time::Instant;

use crate::auth_config::AuthConfig;
use openssl::sha::sha256;
use openssl::ssl::SslStream;

use serde_json::Value as Json;

use crate::crypto_utils::*;
use crate::protocol_utils::*;
use crate::evidence_utils::*;
use crate::tls_utils::{build_dtls_acceptor, ConnectedUdpStream};

pub fn drone_run(cfg: AuthConfig) -> Result<(), Box<dyn Error>> {
    /* key loading */
    let drone_private_key = load_private_key(&cfg.self_privkey)?;
    let receiver_public_key = load_public_key(&cfg.peer_pubkey)?;
    let provider_public_key = load_public_key(&cfg.provider_pubkey)?;

    /* token & sig_token loading (provided by P) */
    let drone_token: Json =
        serde_json::from_slice(&fs::read(&cfg.token)?)?;
    let drone_token_signature_hex =
        String::from_utf8(fs::read(&cfg.sig_token)?)?;

    /* create expected receiver owner_mark (HASH(PU_R)) for later use */
    let receiver_public_key_hash_hex = hex::encode(sha256(&fs::read(&cfg.peer_pubkey)?));

    /*---------------------------------------------------------------------------*/
    /*                      DTLS (UDP) SOCKET INITIALIZATION                     */
    /*---------------------------------------------------------------------------*/
    let acceptor = build_dtls_acceptor(&cfg.self_cert, &cfg.self_privkey, &cfg.ca_cert)?;

    let addr = cfg.listen_addr.as_ref().ok_or("Listen address is set to None (must be set)")?;

    let socket = UdpSocket::bind(addr)?;
    println!("[DRONE] Listening (DTLS/UDP) on {addr}...");

    let mut peek_buf = [0u8; 4096];
    let (n, peer_addr) = socket.recv_from(&mut peek_buf)?;
    if n == 0 {
        return Err("[DRONE] recv_from() failed before DTLS handshake (0 bytes)".into());
    }
    println!("[DRONE] First UDP datagram from {peer_addr}. Starting DTLS handshake...");
    
    /* Timer for runtime */
    let start: Instant = Instant::now();
    
    socket.connect(peer_addr)?;

    // Feed the first received datagram to OpenSSL so it can complete the handshake.
    let udp_stream = ConnectedUdpStream::new_connected_with_first_datagram(
        socket,
        peek_buf[..n].to_vec(),
    );

    let mut stream: SslStream<ConnectedUdpStream> = acceptor.accept(udp_stream)?;
    println!(
        "[DRONE] DTLS handshake OK. Peer cert presented: {}\n",
        stream.ssl().peer_certificate().is_some()
    );

    /*---------------------------------------------------------------------------*/
    /*          Step 2: RECEIVER VERIFICATION (tokenR + owner_mark).             */
    /*---------------------------------------------------------------------------*/
    let mut recv_buffer = [0u8; 4096];
    let bytes_read = stream.read(&mut recv_buffer)?;
    if bytes_read == 0 {
        return Err("[DRONE] read() failed on INIT_AUTH (0 bytes)".into());
    }

    let init_auth_raw = String::from_utf8_lossy(&recv_buffer[..bytes_read]).to_string();
    println!("[DRONE] Reading INIT_AUTH ({bytes_read} bytes).");

    let init_auth_message: Json = serde_json::from_str(&init_auth_raw)?;
    if init_auth_message["type"] != "INIT_AUTH" {
        return Err("[DRONE] Unexpected message type (expected INIT_AUTH)".into());
    }

    let receiver_capability = &init_auth_message["capabilityR"];
    let receiver_token = &receiver_capability["token"];

    let receiver_token_signature = hex::decode(
        receiver_capability["sig"]
            .as_str()
            .ok_or("[DRONE] Missing sig in capabilityR")?,
    )?;

    let receiver_challenge = init_auth_message["challengeR"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    println!("[DRONE] Received challengeR: {receiver_challenge}");

    /* tokenR verify */
    let receiver_token_bytes = serde_json::to_vec(receiver_token)?;
    if !rsa_verify(
        &provider_public_key,
        &receiver_token_bytes,
        &receiver_token_signature,
    )? {
        return Err("[DRONE] tokenR signature INVALID (Provider)".into());
    }
    println!("[DRONE] tokenR signature OK.");

    /* owner_mark verify */
    let receiver_owner_mark = receiver_token["owner_mark"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    if receiver_owner_mark != receiver_public_key_hash_hex {
        return Err("[DRONE] tokenR owner_mark mismatch!".into());
    }
    println!("[DRONE] tokenR owner_mark matches receiver_pub.\n");

    /*---------------------------------------------------------------------------*/
    /*       Step 3: DRONE RESPONSE (responseD + challengeD + capabilityD)       */
    /*---------------------------------------------------------------------------*/
    let order_id = receiver_token["order_id"]
        .as_str()
        .unwrap_or_default()
        .to_string();
    let nonce_session = receiver_token["nonce_session"]
        .as_str()
        .unwrap_or_default()
        .to_string();

    println!("[DRONE] order_id={order_id} nonce_session={nonce_session}");

    let drone_challenge = random_hex_string(16)?;
    println!("[DRONE] Generated challengeD: {drone_challenge}");

    /* 1. create: (challengeR || nonce_session || order_id) */
    let drone_auth_string = make_auth_string(&receiver_challenge, &nonce_session, &order_id);
    /* 2. create responseD = Sign(PR_D, HASH(challengeR || nonce_session || order_id)) 
     * IMPORTANT:
     *     the HASH(), more precisely SHA256(), happens inside rsa_sign()
     */
    let drone_response_signature_hex = hex::encode(rsa_sign(&drone_private_key, &drone_auth_string.as_bytes())?);

    /* create capabilityD = (tokenD, sig_tokenD) */
    let drone_capability = serde_json::json!({
        "token": drone_token,
        "sig": drone_token_signature_hex.trim(),
    });

    /* create DRONE_RESPONSE msg D → R: (capabilityD, challengeD, responseD) */
    let drone_response_message = serde_json::json!({
        "type": "DRONE_RESPONSE",
        "capabilityD": drone_capability,
        "challengeD": drone_challenge,
        "responseD": drone_response_signature_hex,
    });

    /* send DRONE_RESPONSE msg */
    let drone_response_json = drone_response_message.to_string();
    stream.write_all(drone_response_json.as_bytes())?;
    println!(
        "[DRONE] Sent DRONE_RESPONSE (capabilityD, challengeD, responseD) ({} bytes).\n",
        drone_response_json.len()
    );

    /*---------------------------------------------------------------------------*/
    /*                  Step 6: RECEIVER VERIFICATION (responseR)                */
    /*---------------------------------------------------------------------------*/
    /* reading RECEIVER_FINAL msg R → D : responseR */
    let bytes_read = stream.read(&mut recv_buffer)?;
    if bytes_read == 0 {
        return Err("[DRONE] read() failed on RECEIVER_FINAL (0 bytes)".into());
    }
    let receiver_final_raw = String::from_utf8_lossy(&recv_buffer[..bytes_read]).to_string();
    println!("[DRONE] Reading RECEIVER_FINAL ({bytes_read} bytes)");

    let receiver_final_message: Json = serde_json::from_str(&receiver_final_raw)?;
    if receiver_final_message["type"] != "RECEIVER_FINAL" {
        return Err("[DRONE] Unexpected FINAL message type.".into());
    }

    let receiver_response_signature = hex::decode(
        receiver_final_message["responseR"]
            .as_str()
            .unwrap_or_default(),
    )?;
    /* 1. create: (challengeD || nonce_session || order_id) */
    let receiver_auth_string = make_auth_string(&drone_challenge, &nonce_session, &order_id);
    /* 2. responseR (Sign(PR_D, HASH(challengeD || nonce_session || order_id))) verify */
    let ok = rsa_verify(
        &receiver_public_key,
        receiver_auth_string.as_bytes(),
        &receiver_response_signature,
    )?;
    println!("[DRONE] receiver RECEIVER_FINAL VALID.\n");

    /*---------------------------------------------------------------------------*/
    /*                         AUTH RESULT + EVIDENCE                            */
    /*---------------------------------------------------------------------------*/
    /* Prepare ACK signed by drone (in order to let client know that 
     *   the whole authentication was successfully even from server side) 
     */ 
    let status = if ok { "OK" } else { "FAIL" };
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)?
        .as_secs();
    let ack_payload = format!("AUTH_RESULT|{}|{}|{}|{}", status, order_id, nonce_session, ts);
    let ack_sig_hex = hex::encode(rsa_sign(&drone_private_key, ack_payload.as_bytes())?);

    let auth_result_msg = serde_json::json!({
        "type": "AUTH_RESULT",
        "status": status,
        "ts": ts,
        "sig": ack_sig_hex,
    });
    let auth_result_json = auth_result_msg.to_string();
    stream.write_all(auth_result_json.as_bytes())?;
    println!("[DRONE] Sent AUTH_RESULT ({} bytes).", auth_result_json.len());

    if ok {
        println!("[DRONE] Mutual auth completed!");
        store_auth_evidence(
            "AUTH_OK",
            "DRONE",
            "logs/drone_evidence.jsonl",
            &order_id,
            &nonce_session,
            &drone_private_key,
            ts
        )?;
        println!("[DRONE] Evidence successfully written.");

    }

    /* Ending runtime timer */
    let duration = start.elapsed();
    println!("\nRun time: {:?}", duration);

    Ok(())

}
