use std::process::Command;

pub fn setup_wifi_infrastructure() {
    println!("Wi-Fi configurating...");

    /* Execute script to setup Wi-Fi DIRECT */
    Command::new("bash")
        .arg("bash/wifi_setup.sh")
        .status()
        .expect("Wi-Fi setup failed.");


}