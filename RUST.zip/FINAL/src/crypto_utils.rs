use openssl::error::ErrorStack;
use openssl::hash::MessageDigest;
use openssl::pkey::{PKey, Private, Public};
use openssl::rand::rand_bytes;
use openssl::sign::{Signer, Verifier};

use std::fs;
use std::path::Path;

pub type PrivateKey = PKey<Private>;
pub type PublicKey = PKey<Public>;

/* Generate a hexadecimal string of length nbytes * 2 using OpenSSL’s CSPRNG */
pub fn random_hex_string(nbytes: usize) -> Result<String, ErrorStack> {
    let mut buf = vec![0u8; nbytes];
    rand_bytes(&mut buf)?;
    Ok(hex::encode(&buf))
}

/* Load a PEM-encoded private key into a PKey<Private> */
pub fn load_private_key<P: AsRef<Path>>(
    path: P,
) -> Result<PrivateKey, Box<dyn std::error::Error>> {
    let pem = fs::read(path)?;
    let key = PKey::private_key_from_pem(&pem)?;
    Ok(key)
}

/* Load a PEM-encoded public key into a PKey<Public> */
pub fn load_public_key<P: AsRef<Path>>(
    path: P,
) -> Result<PublicKey, Box<dyn std::error::Error>> {
    let pem = fs::read(path)?;
    let key = PKey::public_key_from_pem(&pem)?;
    Ok(key)
}

/* Generate an RSA (SHA-256) signature of the data (the data is first hashed using SHA-256) */
pub fn rsa_sign(priv_key: &PrivateKey, data: &[u8]) -> Result<Vec<u8>, ErrorStack> {
    let mut signer = Signer::new(MessageDigest::sha256(), priv_key)?;
    signer.update(data)?;
    signer.sign_to_vec()
}

/* Verify an RSA signature generated using SHA-256 */
pub fn rsa_verify(pub_key: &PublicKey, data: &[u8], sig: &[u8]) -> Result<bool, ErrorStack> {
    let mut verifier = Verifier::new(MessageDigest::sha256(), pub_key)?;
    verifier.update(data)?;
    verifier.verify(sig)
}
