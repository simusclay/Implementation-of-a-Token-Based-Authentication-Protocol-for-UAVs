# UAV Authentication Protocol – Sender ↔ Drone

This project implements a **mutual authentication protocol** between:

- **sender_client** — executed on the sender PC or smartphone 
- **drone_server** — executed on the drone (Raspberry Pi) or simulated locally  

The authentication workflow uses:

- RSA key pairs (OpenSSL)
- JSON tokens signed by a provider
- SHA-256 hashing (OpenSSL)
- Hex-encoded signatures
- Challenge/response with nonces
- TCP communication on port **8080**

---

## Project Structure

The project is divided into **two main independent folders**

### sender_client/
-  sender_client.cpp
-  CMakeLists.txt
-  common/
    - crypto_utils.h
    - crypto_utils.cpp
    - protocol_utils.h
    - protocol_utils.cpp
- keys/ (demo RSA keys: provider_pub.pem, sender_priv.pem, drone_pub.pem)
- tokens/ (tokenS.json, sigTokenS.hex)

### drone_sender/
- drone_server.cpp
-  CMakeLists.txt
-  common/
    - crypto_utils.h
    - crypto_utils.cpp
    - protocol_utils.h
    - protocol_utils.cpp
- keys/ (demo RSA keys: provider_pub.pem, sender_pub.pem, drone_priv.pem)
- tokens/ (tokenD.json, sigTokenD.hex)


> `common/` appears in both folders so that each component can be compiled on different devices independently (e.g., PC ↔ Raspberry Pi) 
> 
> It will be implemented on Git to reduce redundancy.

---

## Dependencies

Both components require:

- **CMake ≥ 3.12**
- **C++17 compiler**
- **OpenSSL** (SSL + Crypto libraries)
- **nlohmann_json** library

Below are installation instructions for macOS (preferrably Apple Silicon) and Linux.

---

## Installing Dependencies

### macOS (Apple Silicon)

Install via Homebrew:

```bash
brew install cmake openssl@3 nlohmann-json
```

### Linux 


```bash 
sudo apt update
sudo apt install -y build-essential cmake libssl-dev nlohmann-json3-dev
```

## Build instructions
Both components use CMake and must be built independently.
### Building drone_server:
```bash 
cd drone_sender
mkdir build
cd build
cmake ..
make
```
Executable located in: /drone_sender/build/ (named: drone_sender)

### Building sender_client:
```bash 
cd sender_client
mkdir build
cd build
cmake ..
make
```
Executable located in: sender_build/build/ (named: sender_client)

## Run instructions
> Be careful to run these files as listed below, as you have to be in that precise directory (to retrieve correctly the keys and token paths)

On **Terminal 1** (run this one first as it is the server):
```bash
cd drone_sender
./build/drone_server
```
On **Terminal 2** (run this secondly as it is the client and requires the server to be listening):
```bash
cd sender_client
./build/sender_client
```
