// drone_server.cpp
#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <ctime>

#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <openssl/ssl.h>
#include <openssl/err.h>

#include <nlohmann/json.hpp>

#include "../common/crypto_utils.h"
#include "../common/protocol_utils.h"

using json = nlohmann::json;

/* dTLS files */
static const char* DTLS_SERVER_CERT = "../certs/drone.crt";
static const char* DTLS_SERVER_KEY  = "../keys/drone_priv.pem";
static const char* DTLS_CA_CERT     = "../certs/provider_ca.crt";

int main() {

    int ret = 0;
    int client_fd = -1;
    int server_fd = -1;

    struct timespec t_start{}, t_end{};

    SSL_CTX* ctx = nullptr;
    SSL* ssl = nullptr;

    EVP_PKEY* drone_priv = nullptr;
    EVP_PKEY* receiver_pub = nullptr;
    EVP_PKEY* provider_pub = nullptr;

    do {
        /* key loading */
        drone_priv = load_key("../keys/drone_priv.pem", true);
        receiver_pub = load_key("../keys/receiver_pub.pem", false);
        provider_pub = load_key("../keys/provider_pub.pem", false);

        if (!drone_priv || !receiver_pub || !provider_pub) {
            std::cerr << "[DRONE] Error loading keys.\n";
            break;
        }

        /* token & sig_token loading (provided by P) */
        std::string tokenD_str     = load_file("../tokens/tokenD.json");
        std::string sig_tokenD_hex = load_file("../tokens/sig_tokenD.hex");
        if (tokenD_str.empty() || sig_tokenD_hex.empty()) {
            std::cerr << "[DRONE] Error loading tokenD or sig_tokenD.\n";
            break;
        }

        json tokenD = json::parse(tokenD_str);
        std::string sig_tokenD_bin = from_hex(sig_tokenD_hex);

        /* create expected receiver owner_mark (HASH(PU_R)) for later use */
        std::string receiver_pub_pem      = load_file("../keys/receiver_pub.pem");
        std::string receiver_pub_hash_bin = sha256(receiver_pub_pem);
        std::string receiver_pub_hash_hex = to_hex(receiver_pub_hash_bin);

        /*---------------------------------------------------------------------------*/
        /*                      DTLS (UDP) SOCKET INITIALIZATION                     */
        /*---------------------------------------------------------------------------*/
        server_fd = socket(AF_INET, SOCK_DGRAM, 0);
        /* 
         * SOCK_STREAM = TCP, SOCK_DGRAM = UDP 
         * AF_INET = use ipv4, AF_INET6 = use ipv6
         */
        if (server_fd < 0) {
            perror("[DRONE] socket");
            break;    
        }

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(8080);

        if (bind(server_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
            perror("[DRONE] bind");
            break;
        }

        std::cout << "[DRONE] Listening on port 8080...\n";

        SSL_library_init();
        SSL_load_error_strings();
        OpenSSL_add_ssl_algorithms();

        ctx = SSL_CTX_new(DTLS_server_method());
        if (!ctx) {
            std::cerr << "[DRONE] SSL_CTX_new failed.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        /* DTLS certificate configuration */
        if (SSL_CTX_use_certificate_file(ctx, DTLS_SERVER_CERT, SSL_FILETYPE_PEM) != 1) {
            std::cerr << "[DRONE] SSL_CTX_use_certificate_file failed (" << DTLS_SERVER_CERT << ").\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_use_PrivateKey_file(ctx, DTLS_SERVER_KEY, SSL_FILETYPE_PEM) != 1) {
            std::cerr << "[DRONE] SSL_CTX_use_PrivateKey_file failed (" << DTLS_SERVER_KEY << ").\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_check_private_key(ctx) != 1) {
            std::cerr << "[DRONE] Server private key does not match the certificate.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_load_verify_locations(ctx, DTLS_CA_CERT, nullptr) != 1) {
            std::cerr << "[DRONE] SSL_CTX_load_verify_locations failed (" << DTLS_CA_CERT << ").\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        /* Require and verify the client's certificate (mTLS). */
        SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT, nullptr);
        SSL_CTX_set_verify_depth(ctx, 4);

        /* Reasonable DTLS iphers (disable anonymous/NULL). */
        SSL_CTX_set_cipher_list(ctx, "HIGH:!aNULL:!eNULL:!MD5:!RC4");
        SSL_CTX_set_read_ahead(ctx, 1);

        /* Identify peer address before starting DTLS handshake */
        sockaddr_in client_addr{};
        socklen_t client_len = sizeof(client_addr);
        unsigned char peek_buf[1];
        ssize_t peeked = recvfrom(server_fd, peek_buf, sizeof(peek_buf), MSG_PEEK,
                                  (sockaddr*)&client_addr, &client_len);

        /* Timer for runtime */
        clock_gettime(CLOCK_MONOTONIC, &t_start);

        if (peeked <= 0) {
            perror("[DRONE] recvfrom");
            break;
        }

        if (connect(server_fd, (sockaddr*)&client_addr, client_len) < 0) {
            perror("[DRONE] connect");
            break;
        }
        client_fd = server_fd;

        BIO* bio = BIO_new_dgram(client_fd, BIO_NOCLOSE);
        if (!bio) {
            std::cerr << "[DRONE] BIO_new_dgram failed.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        ssl = SSL_new(ctx);
        if (!ssl) {
            std::cerr << "[DRONE] SSL_new failed.\n";
            ERR_print_errors_fp(stderr);
            BIO_free(bio);
            break;
        }
        SSL_set_bio(ssl, bio, bio);

        if (SSL_accept(ssl) <= 0) {
            std::cerr << "[DRONE] SSL_accept failed.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        std::cout << "[DRONE] Client connected with dTLS.\n";

        /*---------------------------------------------------------------------------*/
        /*          Step 2: RECEIVER VERIFICATION (tokenR + owner_mark).             */
        /*---------------------------------------------------------------------------*/
        char buffer[4096];
        memset(buffer, 0, sizeof(buffer));
        ssize_t r = SSL_read(ssl, buffer, sizeof(buffer));
        if (r <= 0) {
            std::cerr << "[DRONE] read() failed on INIT_AUTH.\n";
            break;
        }

        std::string raw_init(buffer, buffer + r);
        std::cout << "[DRONE] Reading INIT_AUTH (" << r << " bytes):\n";

        json init_auth;
        try {
            init_auth = json::parse(raw_init);
        } catch (const std::exception &e) {
            std::cerr << "[DRONE] JSON parse error on INIT_AUTH: " << e.what() << "\n";
            break;
        }

        if (init_auth.value("type", "") != "INIT_AUTH") {
            std::cerr << "[DRONE] Unexpected message type (expected INIT_AUTH).\n";
            break;
        }

        json capabilityR = init_auth["capabilityR"];
        json tokenR      = capabilityR["token"];
        std::string sig_tokenR_hex = capabilityR["sig"];
        std::string sig_tokenR_bin = from_hex(sig_tokenR_hex);

        std::string challengeR = init_auth.value("challengeR", "");
        std::cout << "[DRONE] Received challengeR: " << challengeR << "\n";

        /* tokenR verify */
        bool tokenR_ok = rsa_verify(provider_pub, tokenR.dump(), sig_tokenR_bin);
        if (!tokenR_ok) {
            std::cerr << "[DRONE] tokenR signature INVALID (Provider).\n";
            break;
        }
        std::cout << "[DRONE] tokenR signature OK.\n";

        /* owner_mark verify */
        std::string owner_mark_R = tokenR.value("owner_mark", "");
        if (owner_mark_R != receiver_pub_hash_hex) {
            std::cerr << "[DRONE] tokenR owner_mark mismatch! (not this receiver_pub)\n";
            break;
        } else {
            std::cout << "[DRONE] tokenR owner_mark matches receiver_pub.\n";
        }

        /*---------------------------------------------------------------------------*/
        /*       Step 3: DRONE RESPONSE (responseD + challengeD + capabilityD)       */
        /*---------------------------------------------------------------------------*/
        std::string order_id      = tokenR.value("order_id", "");
        std::string nonce_session = tokenR.value("nonce_session", "");

        std::cout << "[DRONE] order_id=" << order_id
                << " nonce_session=" << nonce_session << "\n";

        std::string challengeD = random_hex_string(16);
        std::cout << "[DRONE] Generated challengeD: " << challengeD << "\n";

        /* 1. create: (challengeR || nonce_session || order_id) */
        std::string auth_str_D  = make_auth_string(challengeR, nonce_session, order_id);
        
        /* 2. create responseD = Sign(PR_D, HASH(challengeR || nonce_session || order_id))
         * IMPORTANT:
         *     the HASH(), more precisely SHA256(), happens inside rsa_sign()
         */
        std::string responseD_bin = rsa_sign(drone_priv, auth_str_D);
        if (responseD_bin.empty()) {
            std::cerr << "[DRONE] Error signing responseD.\n";
            break;
        }
        std::string responseD_hex = to_hex(responseD_bin);

        /* create capabilityD = (tokenD, sig_tokenD) */
        json capabilityD = {
            {"token", tokenD},
            {"sig",   sig_tokenD_hex}
        };

        /* create DRONE_RESPONSE msg D → R: (capabilityD, challengeD, responseD) */
        json drone_response = {
            {"type",        "DRONE_RESPONSE"},
            {"capabilityD", capabilityD},
            {"challengeD",  challengeD},
            {"responseD",   responseD_hex}
        };

        /* send DRONE_RESPONSE msg */
        std::string serialized2 = drone_response.dump();
        ssize_t w = SSL_write(ssl, serialized2.c_str(), serialized2.size());
        std::cout << "[DRONE] Sent DRONE_RESPONSE (" << w << " bytes).\n";

        /*---------------------------------------------------------------------------*/
        /*                  Step 6: RECEIVER VERIFICATION (responseR)                */
        /*---------------------------------------------------------------------------*/
        /* reading RECEIVER_FINAL msg R → D : responseR */
        memset(buffer, 0, sizeof(buffer));
        r = SSL_read(ssl, buffer, sizeof(buffer));
        if (r <= 0) {
            std::cerr << "[DRONE] read() failed on RECEIVER_FINAL.\n";
            break;
        }

        std::string raw_final(buffer, buffer + r);
        std::cout << "[DRONE] Reading RECEIVER_FINAL (" << r << " bytes):\n";

        json receiver_final;
        try {
            receiver_final = json::parse(raw_final);
        } catch (const std::exception &e) {
            std::cerr << "[DRONE] JSON parse error on FINAL: " << e.what() << "\n";
            break;
        }

        if (receiver_final.value("type", "") != "RECEIVER_FINAL") {
            std::cerr << "[DRONE] Unexpected FINAL message type.\n";
            break;
        }

        /* extracting all fields from RECEIVER_FINAL msg */
        std::string responseR_hex = receiver_final.value("responseR", "");
        std::string responseR_bin = from_hex(responseR_hex);

        /* 1. create: (challengeD || nonce_session || order_id) */
        std::string auth_str_R  = make_auth_string(challengeD, nonce_session, order_id);

        /* 2. responseR (Sign(PR_D, HASH(challengeD || nonce_session || order_id))) verify */
        bool ok = rsa_verify(receiver_pub, auth_str_R, responseR_bin);
        if (ok) {
            std::cout << "[DRONE] Receiver SIGNATURE VALID! Mutual auth complete.\n";
        } else {
            std::cout << "[DRONE] INVALID signature from receiver.\n";
        }




        /*---------------------------------------------------------------------------*/
        /*                         AUTH RESULT + EVIDENCE                            */
        /*---------------------------------------------------------------------------*/

        std::string status = ok ? "OK" : "FAIL";
        uint64_t ts = std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();

        std::string ack_payload =
            "AUTH_RESULT|" + status + "|" + order_id + "|" +
            nonce_session + "|" + std::to_string(ts);

        std::string ack_sig_hex = to_hex(rsa_sign(drone_priv, ack_payload));

        json auth_result = {
            {"type", "AUTH_RESULT"},
            {"status", status},
            {"ts", ts},
            {"sig", ack_sig_hex}
        };

        std::string auth_result_json = auth_result.dump();
        SSL_write(ssl, auth_result_json.c_str(), auth_result_json.size());

        std::cout << "[DRONE] Sent AUTH_RESULT status=" << status << ".\n";

        if (ok) {
            store_auth_evidence(
                "AUTH_OK",
                "DRONE",
                "../logs/drone_evidence.jsonl",
                order_id,
                nonce_session,
                drone_priv,
                ts
            );
        }

    } while (false);

    /* CLEANUP */

    if (ssl) {
        SSL_shutdown(ssl);
        SSL_free(ssl);
    }
    if (ctx) {
        SSL_CTX_free(ctx);
    }

    if (server_fd >= 0) {
        close(server_fd);
    }
    EVP_PKEY_free(drone_priv);
    EVP_PKEY_free(receiver_pub);
    EVP_PKEY_free(provider_pub);

    /* Stop timer for runtime */
    clock_gettime(CLOCK_MONOTONIC, &t_end);

    double elapsed_ms =
        (t_end.tv_sec - t_start.tv_sec) * 1000.0 +
        (t_end.tv_nsec - t_start.tv_nsec) / 1e6;

    std::cout << "[TIMING] Protocol time = "
        << std::fixed << std::setprecision(1)
        << elapsed_ms << " ms\n";
        
    return ret;
}

