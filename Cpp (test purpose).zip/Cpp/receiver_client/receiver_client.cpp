// receiver_client.cpp
#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>

#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <openssl/ssl.h>
#include <openssl/err.h>

#include <nlohmann/json.hpp>

#include "../common/crypto_utils.h"
#include "../common/protocol_utils.h"

using json = nlohmann::json;

/* dTLS files */
static const char* DTLS_CLIENT_CERT = "../certs/receiver.crt";
static const char* DTLS_CLIENT_KEY  = "../keys/receiver_priv.pem";
static const char* DTLS_CA_CERT     = "../certs/provider_ca.crt";

const char* DRONE_IP = "127.0.0.1"; // LOCAL TESTING
// const char* DRONE_IP = "192.168.2.2"; // RPi TESTING

int main() {

    int ret = 0;
    int sock = -1;
    struct timespec t_start{}, t_end{};

    SSL_CTX* ctx = nullptr;
    SSL* ssl = nullptr;

    EVP_PKEY* receiver_priv = nullptr;
    EVP_PKEY* drone_pub = nullptr;
    EVP_PKEY* provider_pub = nullptr;

    do {

        /* key loading */
        receiver_priv = load_key("../keys/receiver_priv.pem", true);
        drone_pub = load_key("../keys/drone_pub.pem", false);
        provider_pub = load_key("../keys/provider_pub.pem", false);

        if (!receiver_priv || !drone_pub || !provider_pub) {
            std::cerr << "[RECEIVER] Error loading keys.\n";
            break;
        }

        /* tokenR & sig_tokenR loading (provided by P) */
        std::string tokenR_str     = load_file("../tokens/tokenR.json");
        std::string sig_tokenR_hex = load_file("../tokens/sig_tokenR.hex");
        if (tokenR_str.empty() || sig_tokenR_hex.empty()) {
            std::cerr << "[RECEIVER] Error loading tokenR or sig_tokenR.\n";
            break;
        }

        json tokenR = json::parse(tokenR_str);
        std::string sig_tokenR_bin = from_hex(sig_tokenR_hex);

        /* create expected drone owner_mark (HASH(PU_D)) for later use */
        std::string drone_pub_pem      = load_file("../keys/drone_pub.pem");
        std::string drone_pub_hash_bin = sha256(drone_pub_pem);
        std::string drone_pub_hash_hex = to_hex(drone_pub_hash_bin);

        /*---------------------------------------------------------------------------*/
        /*                      DTLS (UDP) SOCKET INITIALIZATION                     */
        /*---------------------------------------------------------------------------*/
        sock = socket(AF_INET, SOCK_DGRAM, 0); 
        /* 
        * SOCK_STREAM = TCP, SOCK_DGRAM = UDP 
        * AF_INET = use ipv4, AF_INET6 = use ipv6
        */
        if (sock < 0) {
            perror("[RECEIVER] socket");
            break;
        }

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(8080);
        inet_pton(AF_INET, DRONE_IP, &addr.sin_addr);

        if (connect(sock, (sockaddr*)&addr, sizeof(addr)) < 0) {
            perror("[RECEIVER] connect");
            break;
        }

        /* Start timer for runtime */
        clock_gettime(CLOCK_MONOTONIC, &t_start);

        SSL_library_init();
        SSL_load_error_strings();
        OpenSSL_add_ssl_algorithms();

        ctx = SSL_CTX_new(DTLS_client_method());
        if (!ctx) {
            std::cerr << "[RECEIVER] SSL_CTX_new failed.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_use_certificate_file(ctx, DTLS_CLIENT_CERT, SSL_FILETYPE_PEM) != 1) {
            std::cerr << "[RECEIVER] SSL_CTX_use_certificate_file failed (" << DTLS_CLIENT_CERT << ").\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_use_PrivateKey_file(ctx, DTLS_CLIENT_KEY, SSL_FILETYPE_PEM) != 1) {
            std::cerr << "[RECEIVER] SSL_CTX_use_PrivateKey_file failed (" << DTLS_CLIENT_KEY << ").\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_check_private_key(ctx) != 1) {
            std::cerr << "[RECEIVER] Client private key does not match the certificate.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        if (SSL_CTX_load_verify_locations(ctx, DTLS_CA_CERT, nullptr) != 1) {
            std::cerr << "[RECEIVER] SSL_CTX_load_verify_locations failed (" << DTLS_CA_CERT << ").\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
        SSL_CTX_set_verify_depth(ctx, 4);

        SSL_CTX_set_cipher_list(ctx, "HIGH:!aNULL:!eNULL:!MD5:!RC4");
        SSL_CTX_set_read_ahead(ctx, 1);

        BIO* bio = BIO_new_dgram(sock, BIO_NOCLOSE);
        if (!bio) {
            std::cerr << "[RECEIVER] BIO_new_dgram failed.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        ssl = SSL_new(ctx);
        if (!ssl) {
            std::cerr << "[RECEIVER] SSL_new failed.\n";
            ERR_print_errors_fp(stderr);
            BIO_free(bio);
            break;
        }
        SSL_set_bio(ssl, bio, bio);

        if (SSL_connect(ssl) <= 0) {
            std::cerr << "[RECEIVER] SSL_connect failed.\n";
            ERR_print_errors_fp(stderr);
            break;
        }

        std::cout << "[RECEIVER] Connected to drone with dTLS.\n";

        /*---------------------------------------------------------------------------*/
        /*    Step 1: RECEIVER INITIATES AUTHENTICATION (capabilityR + challengeR)   */
        /*---------------------------------------------------------------------------*/
        std::string challengeR = random_hex_string(16);   // 16 byte => 32 char hex
        std::cout << "[RECEIVER] Generated challengeR: " << challengeR << "\n";
        
        /* create capabilityR = (tokenR, sig_tokenR) */
        json capabilityR = {
            {"token", tokenR},
            {"sig",   sig_tokenR_hex}
        };

        /* create INIT_AUTH msg = (capabilityR, challengeR) */
        json init = {
            {"type",        "INIT_AUTH"},
            {"challengeR",  challengeR},
            {"capabilityR", capabilityR}
        };

        /* send INIT_AUTH msg */
        std::string serialized_init = init.dump();
        ssize_t w = SSL_write(ssl, serialized_init.c_str(), serialized_init.size());
        std::cout << "[RECEIVER] Sent INIT_AUTH (" << w << " bytes).\n";

        /*---------------------------------------------------------------------------*/
        /*             Step 4: DRONE VERIFICATION (tokenD + owner_mark)              */
        /*---------------------------------------------------------------------------*/
        /* reading DRONE_RESPONSE msg D → R: (capabilityD, challengeD, responseD) */
        char buffer[4096];
        memset(buffer, 0, sizeof(buffer));
        ssize_t r = SSL_read(ssl, buffer, sizeof(buffer));
        if (r <= 0) {
            std::cerr << "[RECEIVER] read() failed on DRONE_RESPONSE.\n";
            break;
        }

        std::string raw_resp(buffer, buffer + r);
        std::cout << "[RECEIVER] Raw DRONE_RESPONSE (" << r << " bytes):\n";

        json drone_response;
        try {
            drone_response = json::parse(raw_resp);
        } catch (const std::exception &e) {
            std::cerr << "[RECEIVER] JSON parse error on DRONE_RESPONSE: "
                    << e.what() << "\n";
            break;
        }

        if (drone_response.value("type", "") != "DRONE_RESPONSE") {
            std::cerr << "[RECEIVER] Unexpected message type (expected DRONE_RESPONSE).\n";
            break;
        }

        /* extracting all fields from DRONE_RESPONSE msg */
        json capabilityD = drone_response["capabilityD"];
        json tokenD = capabilityD["token"];
        std::string sig_tokenD_hex = capabilityD["sig"];
        std::string sig_tokenD_bin = from_hex(sig_tokenD_hex);

        std::string challengeD = drone_response.value("challengeD", "");
        std::string responseD_hex = drone_response.value("responseD", "");
        std::string responseD_bin = from_hex(responseD_hex);

        std::cout << "[RECEIVER] challengeD: " << challengeD << "\n";

        /* tokenD verify */
        bool tokenD_ok = rsa_verify(provider_pub, tokenD.dump(), sig_tokenD_bin);
        if (!tokenD_ok) {
            std::cerr << "[RECEIVER] tokenD signature INVALID (Provider).\n";
            break;
        }
        std::cout << "[RECEIVER] tokenD signature OK.\n";

        /* owner_mark verify */
        std::string owner_mark_D = tokenD.value("owner_mark", "");
        if (owner_mark_D != drone_pub_hash_hex) {
            std::cerr << "[RECEIVER] tokenD owner_mark mismatch! (not this drone_pub)\n";
        } else {
            std::cout << "[RECEIVER] tokenD owner_mark matches drone_pub.\n";
        }
        
        std::string order_id = tokenD.value("order_id", "");
        std::string nonce_session = tokenD.value("nonce_session", "");
        std::cout << "[RECEIVER] order_id=" << order_id
                << " nonce_session=" << nonce_session << "\n";

        /* 1. create: (challengeR || nonce_session || order_id) */
        std::string auth_str_D  = make_auth_string(challengeR, nonce_session, order_id);

        /* 2. responseD (Sign(PR_D, HASH(challengeR || nonce_session || order_id))) verify */
        bool sig_ok = rsa_verify(drone_pub, auth_str_D, responseD_bin);
        if (!sig_ok) {
            std::cout << "[RECEIVER] ERROR: Drone SIGNATURE INVALID!\n";
            break;
        } else {
            std::cout << "[RECEIVER] Drone SIGNATURE VALID.\n";
        }

        /*---------------------------------------------------------------------------*/
        /*                   Step 5: RECEIVER RESPONSE (responseR)                   */
        /*---------------------------------------------------------------------------*/
        /* 1. create: (challengeD || nonce_session || order_id) */
        std::string auth_str_R  = make_auth_string(challengeD, nonce_session, order_id);

        /* 2. create responseR = Sign(PR_R, HASH(challengeD || nonce_session || order_id)) */
        std::string responseR_bin = rsa_sign(receiver_priv, auth_str_R);
        if (responseR_bin.empty()) {
            std::cerr << "[RECEIVER] Error signing responseR.\n";
            break;
        }
        std::string responseR_hex = to_hex(responseR_bin);

        json final = {
            {"type",      "RECEIVER_FINAL"},
            {"responseR", responseR_hex}
        };

        /* 3. send responseR */
        std::string serialized_final = final.dump();
        w = SSL_write(ssl, serialized_final.c_str(), serialized_final.size());
        std::cout << "[RECEIVER] Sent RECEIVER_FINAL (" << w << " bytes).\n";

        /*---------------------------------------------------------------------------*/
        /*       Step 7: RECEIVE AUTH_RESULT (Drone ACK) and store evidence          */
        /*---------------------------------------------------------------------------*/
        char ack_buf[4096];
        memset(ack_buf, 0, sizeof(ack_buf));
        ssize_t r_ack = SSL_read(ssl, ack_buf, sizeof(ack_buf));
        if (r_ack <= 0) {
            std::cerr << "[RECEIVER] Failed to read AUTH_RESULT.\n";
            break;
        }

        json auth_result = json::parse(ack_buf);

        if (auth_result["type"] != "AUTH_RESULT") {
            std::cerr << "[RECEIVER] Unexpected message type.\n";
            break;
        }

        std::string status = auth_result["status"];
        uint64_t ts = auth_result["ts"];
        std::string sig_hex = auth_result["sig"];

        std::string payload =
            "AUTH_RESULT|" + status + "|" + order_id + "|" +
            nonce_session + "|" + std::to_string(ts);

        std::string sig_bin = from_hex(sig_hex);

        /* Check if the ack is actually from the Drone by rsa_verify */
        if (!rsa_verify(drone_pub, payload, sig_bin)) {
            std::cerr << "[RECEIVER] Invalid AUTH_RESULT signature.\n";
            break;
        }

        std::cout << "[RECEIVER] AUTH_RESULT verified: " << status << "\n";

        if (status == "OK") {
            store_auth_evidence(
                "AUTH_OK",
                "RECEIVER",
                "../logs/receiver_evidence.jsonl",
                order_id,
                nonce_session,
                receiver_priv,
                ts
            );
        }


    } while (false);

    /* CLEANUP */
    if (ssl) {
        SSL_shutdown(ssl);
        SSL_free(ssl);
    }
    if (ctx) {
        SSL_CTX_free(ctx);
    }
    if (sock >= 0) {
        close(sock);
    }

    EVP_PKEY_free(receiver_priv);
    EVP_PKEY_free(drone_pub);
    EVP_PKEY_free(provider_pub);

    /* Stop timer for runtime */
    clock_gettime(CLOCK_MONOTONIC, &t_end);

    double elapsed_ms =
        (t_end.tv_sec - t_start.tv_sec) * 1000.0 +
        (t_end.tv_nsec - t_start.tv_nsec) / 1e6;

    std::cout << "[TIMING] Protocol time = "
        << std::fixed << std::setprecision(1)
        << elapsed_ms << " ms\n";

    return ret;
}
