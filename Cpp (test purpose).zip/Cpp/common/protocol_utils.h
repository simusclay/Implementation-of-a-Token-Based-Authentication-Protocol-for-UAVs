#pragma once

#include <string>
#include <fstream>
#include <nlohmann/json.hpp>
#include <ctime>
#include <openssl/evp.h>

std::string hash_token_json(const nlohmann::json &token);

std::string make_auth_string(const std::string &challenge,
                             const std::string &nonce_session,
                             const std::string &order_id);
            
bool store_auth_evidence(
    const std::string& event_type,      // "AUTH_OK" / "AUTH_FAIL"
    const std::string& role,            // "DRONE" / "RECEIVER"
    const std::string& out_path,         // "../logs/drone_evidence.jsonl"
    const std::string& order_id,
    const std::string& nonce_session,
    EVP_PKEY* signer_privkey,
    uint64_t ts
);

