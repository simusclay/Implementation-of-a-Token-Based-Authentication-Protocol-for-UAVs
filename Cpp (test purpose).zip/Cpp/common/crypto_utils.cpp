#include "crypto_utils.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/sha.h>

/*---------------------------------------------------------------------------*/
/*                             CRYPTO FUNCTIONS:                             */
/*---------------------------------------------------------------------------*/

/* Function to load a file */ 
std::string load_file(const std::string &path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        std::cerr << "[SENDER] Cannot open file: " << path << "\n";
        return {};
    }
    return std::string((std::istreambuf_iterator<char>(f)),
                       std::istreambuf_iterator<char>());
}

/* Function to convert a binary to a hexadecimal */
std::string to_hex(const std::string &bin) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (unsigned char c : bin) {
        oss << std::setw(2) << static_cast<int>(c);
    }
    return oss.str();
}

/* Function to convert a hexadecimal to a binary */
std::string from_hex(const std::string &hex) {
    if (hex.size() % 2 != 0) {
        std::cerr << "[SENDER] from_hex: invalid length\n";
        return {};
    }
    std::string out;
    out.reserve(hex.size() / 2);
    for (size_t i = 0; i < hex.size(); i += 2) {
        std::string byte_str = hex.substr(i, 2);
        long val = strtol(byte_str.c_str(), nullptr, 16);
        out.push_back(static_cast<char>(val));
    }
    return out;
}

/* Function to generate size n random bytes */
std::string random_bytes(size_t n) {
    std::string buf(n, '\0');

    /* RAND_bytes restituisce 1 in caso di successo */
    if (RAND_bytes(reinterpret_cast<unsigned char*>(&buf[0]), static_cast<int>(n)) != 1) {
        throw std::runtime_error("RAND_bytes failed");
    }

    return buf;
}

/* 
 * Function to generate size nbytes*2 random hexadecimal string 
 * 1 byte (0->255) = 2 hex characters (each hexa character from 0->15, 16ˆ2=256)
 */
std::string random_hex_string(size_t nbytes) {
    std::string bin = random_bytes(nbytes);
    return to_hex(bin);
}

/* Function to load a private or a public .PEM key */
EVP_PKEY* load_key(const std::string &path, bool is_private) {
    /* 
     * The pipeline is:
     *      [file PEM] -> string -> BIO -> OpenSSL -> EVP_PKEY
    */
    std::string key = load_file(path);
    if (key.empty()) {
        std::cerr << "[SENDER] Key file empty or missing: " << path << "\n";
        return nullptr;
    }

    BIO *bio = BIO_new_mem_buf(key.data(), (int)key.size());
    if (!bio) { 
        /* memory was not actually allocated (!bio), no need to free the ptr */
        std::cerr << "[SENDER] BIO_new_mem_buf failed for: " << path << "\n";
        return nullptr;
    }

    EVP_PKEY* pk = nullptr;
    if (is_private) {
        pk = PEM_read_bio_PrivateKey(bio, nullptr, nullptr, nullptr);
    } else {
        pk = PEM_read_bio_PUBKEY(bio, nullptr, nullptr, nullptr);
    }
    /* now we have the keys in EVP_PKEY type, no need to keep BIO */
    BIO_free(bio);

    if (!pk) {
        std::cerr << "[SENDER] Failed to load "
                  << (is_private ? "private" : "public")
                  << " key from: " << path << "\n";
    }
    return pk;
}

/* 
 * Function to produce the RSA sign of the input 
 * see https://docs.openssl.org/master/man3/EVP_DigestSignInit/
 */
std::string rsa_sign(EVP_PKEY* priv, const std::string &data) {
    /* working context for hash(sha)+sign */
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    EVP_PKEY_CTX* pctx = nullptr;

    if (!ctx) {
        std::cerr << "[SENDER] EVP_MD_CTX_new failed\n";
        return {};
    }

    /* 
     * config ctx to use SHA & private key to sign (and links pctx to the privkey) 
     * pctx will be freed automatically when ctx is freed
     */
    if (EVP_DigestSignInit(ctx, &pctx, EVP_sha256(), nullptr, priv) != 1) {
        std::cerr << "[SENDER] DigestSignInit failed\n";
        EVP_MD_CTX_free(ctx);
        return {};
    }

    /* provide data to sign to ctx */
    if (EVP_DigestSignUpdate(ctx, data.data(), data.size()) != 1) {
        std::cerr << "[SENDER] DigestSignUpdate failed\n";
        EVP_MD_CTX_free(ctx);
        return {};
    }

    size_t siglen = 0;
    /* calculate MAXIMUM signature length to allocate that mem */
    if (EVP_DigestSignFinal(ctx, nullptr, &siglen) != 1) {
        std::cerr << "[SENDER] DigestSignFinal(size) failed\n";
        EVP_MD_CTX_free(ctx);
        return {};
    }

    std::string sig(siglen, '\0');
    /* 
     * use sig[] (made up of \0's) to hold the final signature
     * TODO in this case we used rsa 2048 bit keys -> 256 bytes signatures
     */
    if (EVP_DigestSignFinal(ctx,
                            reinterpret_cast<unsigned char*>(&sig[0]),
                            &siglen) != 1) {
        std::cerr << "[SENDER] DigestSignFinal(data) failed\n";
        EVP_MD_CTX_free(ctx);
        return {};
    }

    EVP_MD_CTX_free(ctx);
    /* 
     * Regarding EVP_DigestSignFinal: 
     *      "If the call is successful the signature is written to sig and the amount of data written to siglen" 
     *      from https://docs.openssl.org/master/man3/EVP_DigestSignInit/
     * therefore siglen size might actually be different before and after the call -> need to resize
     */
    sig.resize(siglen); 
    return sig;
}

/* 
 * Function to verify the RSA signature 
 * see https://docs.openssl.org/master/man3/EVP_DigestVerifyInit/
 */
bool rsa_verify(EVP_PKEY* pub, const std::string &data, const std::string &sig) {
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    EVP_PKEY_CTX* pctx = nullptr;

    if (!ctx) {
        std::cerr << "[SENDER] EVP_MD_CTX_new failed (verify)\n";
        return false;
    }

    if (EVP_DigestVerifyInit(ctx, &pctx, EVP_sha256(), nullptr, pub) != 1) {
        std::cerr << "[SENDER] DigestVerifyInit failed\n";
        EVP_MD_CTX_free(ctx);
        return false;
    }

    if (EVP_DigestVerifyUpdate(ctx, data.data(), data.size()) != 1) {
        std::cerr << "[SENDER] DigestVerifyUpdate failed\n";
        EVP_MD_CTX_free(ctx);
        return false;
    }

    int ok = EVP_DigestVerifyFinal(ctx,
                                   reinterpret_cast<const unsigned char*>(sig.data()),
                                   sig.size());
    EVP_MD_CTX_free(ctx);
    return ok == 1;
}

/* Function to produce SHA256 of the input (and returns a string instead of a char ptr) */
std::string sha256(const std::string &data) {
    /* OpenSSL SHA256 requires a char ptr where it stores the result */
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(data.data()),
           data.size(),
           hash);
    return std::string(reinterpret_cast<char*>(hash), SHA256_DIGEST_LENGTH);
}