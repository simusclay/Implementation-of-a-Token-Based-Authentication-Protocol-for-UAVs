#include <fstream>
#include <ctime>
#include <filesystem>

#include "protocol_utils.h"
#include "crypto_utils.h"

using json = nlohmann::json;

/*---------------------------------------------------------------------------*/
/*                           AUXILIARY FUNCTIONS:                            */
/*---------------------------------------------------------------------------*/

/* Function to hash a token */
std::string hash_token_json(const json &token) {
    std::string dumped = token.dump();
    return sha256(dumped);
}
/* Function to produce the requested authentication string */
std::string make_auth_string(const std::string &challenge,
                             const std::string &nonce_session,
                             const std::string &order_id) {
    return challenge + "|" + nonce_session + "|" + order_id;
}

/* Function that stores authN evidence (append only) */
bool store_auth_evidence(
    const std::string& status,
    const std::string& role,
    const std::string& out_path,
    const std::string& order_id,
    const std::string& nonce_session,
    EVP_PKEY* signer_privkey,
    uint64_t ts
) {

    std::string payload =
        status + "|" + order_id + "|" + nonce_session + "|" + std::to_string(ts);

    std::string sig_bin = rsa_sign(signer_privkey, payload);
    std::string sig_hex = to_hex(sig_bin);

    std::filesystem::path p(out_path);
    if (p.has_parent_path()) {
        std::filesystem::create_directories(p.parent_path());
    }

    std::ofstream ofs(out_path, std::ios::app);
    if (!ofs.is_open()) return false;

    ofs << "{"
        << "\"role\":\"" << role << "\","
        << "\"status\":\"" << status << "\","
        << "\"order_id\":\"" << order_id << "\","
        << "\"nonce_session\":\"" << nonce_session << "\","
        << "\"timestamp_unix\":" << ts << ","
        << "\"payload\":\"" << payload << "\","
        << "\"signature_hex\":\"" << sig_hex << "\","
        << "}\n";

    ofs.flush();
    return true;
}
