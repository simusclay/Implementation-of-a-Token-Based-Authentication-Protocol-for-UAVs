#pragma once

#include <string>
#include <openssl/evp.h>

/* Function to load a file */ 
std::string load_file(const std::string &path);

/* Function to convert a binary to a hexadecimal */
std::string to_hex(const std::string &bin);

/* Function to convert a hexadecimal to a binary */
std::string from_hex(const std::string &hex);

/* Function to generate size n random bytes */
std::string random_bytes(size_t n);

/* 
 * Function to generate size nbytes*2 random hexadecimal string 
 * 1 byte (0->255) = 2 hex characters (each hexa character from 0->15, 16ˆ2=256)
 */
std::string random_hex_string(size_t nbytes);

/* Function to load a private or a public .PEM key */
EVP_PKEY* load_key(const std::string &path, bool is_private);

/* 
 * Function to produce the RSA sign of the input 
 * see https://docs.openssl.org/master/man3/EVP_DigestSignInit/
 */
std::string rsa_sign(EVP_PKEY* priv, const std::string &data);

/* 
 * Function to verify the RSA signature 
 * see https://docs.openssl.org/master/man3/EVP_DigestVerifyInit/
 */
bool rsa_verify(EVP_PKEY* pub, const std::string &data, const std::string &sig);

/* Function to produce SHA256 of the input */
std::string sha256(const std::string &data);