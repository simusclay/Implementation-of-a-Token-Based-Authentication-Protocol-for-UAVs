package com.example.dtlsapp

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.io.File
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import android.os.SystemClock




class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("drone_auth")
        }
    }

    private lateinit var btnConnect: Button
    private var isAuthenticated: Boolean = false

    external fun runClient(
        serverAddr: String,
        sni: String,
        receiverCert: String,
        receiverKey: String,
        caCert: String,
        receiverPrivKeyPem: String,
        dronePubKeyPem: String,
        providerPubKeyPem: String,
        tokenRJson: String,
        sigTokenRHex: String,
        evidencePath: String
    ): String?

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnConnect = findViewById(R.id.btnConnect)
        // btnConnect.isEnabled = false // blocked until authenticated biometrically
        setConnectLocked(true)

        startAuthentication()

        btnConnect.setOnClickListener {
            if (!isAuthenticated) {
                Toast.makeText(this, "Authentication required", Toast.LENGTH_SHORT).show()
                startAuthentication()
                return@setOnClickListener
            }

            // Copy assets in FilesDir and retrieve absolute paths
            val receiverCrt = copyAssetToFilesDir("certs/receiver.crt")
            val receiverKey = copyAssetToFilesDir("keys/receiver_priv.pem")
            val caCrt = copyAssetToFilesDir("certs/provider_ca.crt")

            val receiverPriv = copyAssetToFilesDir("keys/receiver_priv.pem")
            val dronePub = copyAssetToFilesDir("keys/drone_pub.pem")
            val providerPub = copyAssetToFilesDir("keys/provider_pub.pem")

            val tokenR = copyAssetToFilesDir("tokens/tokenR.json")
            val sigTokenR = copyAssetToFilesDir("tokens/sig_tokenR.hex")

            val evidenceFile = File(filesDir, "receiver_evidence.jsonl")
            val evidencePath = evidenceFile.absolutePath

            if (!evidenceFile.exists()) {
                evidenceFile.createNewFile()
            }

            Thread {
                try {

                    if (isConnectedToDrone()) {
                        // start the protocol
                        runOnUiThread {
                            Toast.makeText(
                                this,
                                "Drone found! Starting the protocol...",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                        val t0 = SystemClock.elapsedRealtimeNanos()


                        val result = runClient(
                            "192.168.4.1:8080",
                            "pi.local",
                            receiverCrt,
                            receiverKey,
                            caCrt,
                            receiverPriv,
                            dronePub,
                            providerPub,
                            tokenR,
                            sigTokenR,
                            evidencePath
                        )

                        val t1 = SystemClock.elapsedRealtimeNanos()
                        val elapsedMs = (t1 - t0) / 1_000_000.0  // double with decimals (testing purpose)

                        // result handling on UI
                        runOnUiThread {
                            if (result == "OK") {
                                btnConnect.text = String.format("TIME: %.1f ms", elapsedMs)
                                btnConnect.setBackgroundColor(android.graphics.Color.GREEN)
                                btnConnect.isEnabled = false
                                Toast.makeText(this@MainActivity, "SUCCESSFULLY AUTHENTICATED!", Toast.LENGTH_LONG).show()
                            } else {
                                btnConnect.text = "RETRY"
                                btnConnect.setBackgroundColor(android.graphics.Color.RED)

                                // show the error
                                androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                                    .setTitle("Authentication Error")
                                    .setMessage(result ?: "Unknown error")
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                        }
                    }
                    else {
                        runOnUiThread {
                            Toast.makeText(this, "Drone not found. Check Wi-Fi DIRECT settings.", Toast.LENGTH_LONG).show()
                            openWifiSettings()
                        }
                    }
                } catch (t: Throwable) {
                    android.util.Log.e("DTLSAPP", "Exception: ${t.message}")
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "FATAL ERROR: ${t.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    private fun setConnectLocked(locked: Boolean) {
        btnConnect.isEnabled = true
        btnConnect.alpha = if (locked) 0.4f else 1.0f
    }


    private fun startAuthentication() {
        val biometricManager = BiometricManager.from(this)

        val canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )

        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Authentication not possible on this device", Toast.LENGTH_LONG).show()
            btnConnect.isEnabled = false
            return
        }

        val executor = ContextCompat.getMainExecutor(this)

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Authentication required")
            .setSubtitle("Use fingerprint/face/PIN")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        val biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    isAuthenticated = true
                    // btnConnect.isEnabled = true
                    setConnectLocked(false)
                    Toast.makeText(this@MainActivity, "Authenticated", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(this@MainActivity, "Authentication failed", Toast.LENGTH_SHORT).show()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    isAuthenticated = false
                    //btnConnect.isEnabled = false
                    setConnectLocked(true)

                }
            })

        biometricPrompt.authenticate(promptInfo)
    }

    private fun copyAssetToFilesDir(assetName: String): String {
        val outFile = File(filesDir, assetName)

        outFile.parentFile?.let { parent ->
            if (!parent.exists()) parent.mkdirs()
        }

        try {
            assets.open(assetName).use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            android.util.Log.d("DTLSAPP", "Updated file: ${outFile.absolutePath}")
        } catch (e: Exception) {
            android.util.Log.e("DTLSAPP", "Error copying asset $assetName: ${e.message}")
        }

        return outFile.absolutePath
    }

    private fun isConnectedToDrone(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false

        // 1. Wi-Fi capabilities check
        if (!capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return false

        // 2. IP check (within 192.168.4.x subnet)
        val linkProperties = connectivityManager.getLinkProperties(activeNetwork)
        val hasDroneIp = linkProperties?.linkAddresses?.any {
            it.address.hostAddress?.startsWith("192.168.4.") == true
        } ?: false

        if (hasDroneIp) {
            android.util.Log.e("DTLSAPP", "VALID IP: CONNECTED TO DRONE WIFI")
            return true
        }

        android.util.Log.e("DTLSAPP", "INVALID WIFI")
        return false
    }

    private fun openWifiSettings() {
        // open wifi settings
        val intent = Intent(Settings.ACTION_WIFI_SETTINGS)
        startActivity(intent)
    }

}
